# Science Mania — Android APK builder project

This project wraps the included Science Mania website in a simple Android WebView app.

## Important
This ZIP is an Android project, not a compiled APK. It is configured so GitHub Actions can build a debug APK for free. The app's existing assistant is a simple offline rule-based helper, not a cloud AI chatbot.

## Build the APK free using GitHub Actions
1. Sign in to GitHub and create a new repository (a free account is enough).
2. Upload the contents of this ZIP to the repository (upload the files and folders, not the ZIP itself).
3. Open the repository's **Actions** tab.
4. If prompted, enable Actions.
5. Select **Build Science Mania APK** on the left.
6. Tap **Run workflow** and confirm.
7. Wait for the workflow to finish, open its completed run, and find **Artifacts** at the bottom.
8. Download **Science-Mania-APK** and extract it. The file `app-debug.apk` is the installable test APK.

## Notes
- This debug APK is for testing/sharing, not a Play Store release.
- Android may show a warning when installing an APK from outside the Play Store. Only install APKs you built or trust.
- The project needs internet access only to build in GitHub Actions. The bundled website itself can open offline, but any future online AI feature would need internet and a securely configured AI service.

# Science Mania — Class 9

A free, responsive browser-based starter app designed to work on phones and computers.

## Included
- Responsive 10-panel dashboard
- Offline built-in science study helper (not a live AI service)
- Interactive multiple-choice quiz with feedback and score
- Force calculator (F = m × a)
- Biology diagram checklist
- New and older syllabus chapter lists
- Searchable key-element list
- Searchable biology definitions
- Chapter flowchart summaries and exam tips
- PWA manifest and service worker for install/offline support

## Try it
Open `index.html` in a browser. For best PWA installation and offline support, host the folder on an HTTPS static host or run it through a local development server.

## Install on Android
1. Host this folder on a free HTTPS static host (for example, GitHub Pages).
2. Open the website in Chrome on Android.
3. Use Chrome's menu and choose **Install app** or **Add to Home screen** when available.

This creates an installable web app (PWA). It is not a native APK. A native Android APK can be built later with a suitable Android/Flutter or Capacitor build setup.

## Important notes
- The supplied Flutter source was not directly runnable as-is because `Icons.生物` is not a valid Flutter Material icon. This web version is a separate implementation inspired by the supplied features.
- The chatbot is an offline rule-based helper with sample answers. A truly AI-powered assistant generally needs internet access and an AI provider/API; never put private API keys in browser code.
- Syllabus lists are starter content. Confirm the official syllabus with your school/board for the current academic year.
